﻿#requires -RunAsAdministrator
#requires -PSEdition Desktop
<#
    .SYNOPSIS
    Installs the SQL STIG Compliance data warehouse and application

    .PARAMETER SourceFile
    BACPAC from which the database will be deployed

    .PARAMETER InstallPath
    The target directory for installed script files

    .PARAMETER PolicyServer
    The SQL Server instance hosting the STIG Compliance Datawarehouse

    .PARAMETER DataWarehouseName
    Name of the database to be used for deployment.
    (Default: StigDatawarehouse)

    .PARAMETER CMSGroup
    Path/Name of the CMS group to use for evaluating compliance.

    .PARAMETER CustomerName
    Name of the customer in which this application is deployed.

    .PARAMETER CustomerEmail
    Email address for the POC within the customer team.

    .PARAMETER NumberOfSQLInstances
    Estimated number of instances to be monitored.

    .PARAMETER Upgrade
    Switch to determine whether an existing 

    .EXAMPLE
    TO install or upgrade an instance of STIG Monitor using the UI, use the following command:

    PS> Install-SqlStigMonitor.ps1

    .EXAMPLE
    To install a new instance of STIG Monitor, use the following command

    PS> $installOptions = @{
    >> SourceFile = 'F:\Deploy\deploy\STIGMonitor.bacpac'
    >>  InstallPath = 'F:\StigMonitor'
    >>  PolicyServer = 'SqlStigMonitor\STIG2014'
    >>  DataWarehouseName = 'StigMonitor'
    >>  CMSGroup = 'MAG'
    >>  CustomerName = 'My Organization'
    >>  CustomerEmail = 'user@mail.mil'
    >>  NumberOfSQLInstances = 3
    >> }
    PS> Install-SqlStigMonitor.ps1 @installOptions

    .NOTES
    Disclaimer:
    This is SAMPLE code that is NOT production ready. It is the sole intention of this code to provide a proof of 
    concept as a learning tool for Microsoft Customers. Microsoft does not provide warranty for or guarantee any
    portion of this code and is NOT responsible for any affects it may have on any system it is executed on  or 
    environment it resides within.
    Please use this code at your own discretion!

    Additional legalese:
    This Sample Code is provided for the purpose of illustration only and is not intended to be used in a 
    production environment.
    THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER 
    EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    We grant You a nonexclusive, royalty-free right to use and modify the Sample Code and to reproduce and
    distribute the object code form of the Sample Code, provided that You agree:
        (i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code 
            is embedded;
        (ii) to include a valid copyright notice on Your software product in which the Sample Code is embedded; and
        (iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or lawsuits,
            including attorneys' fees, that arise or result from the use or distribution of the Sample Code.
#>
[CmdletBinding(DefaultParameterSetName = 'GUI')]
param
(
    [Parameter(ParameterSetName = 'CLI', Mandatory = $true, ValueFromPipeline = $true)]
    [String]
    $SourceFile,

    [Parameter(ParameterSetName = 'CLI', Mandatory = $true)]
    [String]
    $InstallPath = 'C:\MSSQL\StigMonitor',

    [Parameter(ParameterSetName = 'CLI', Mandatory = $true)]
    [String]
    $PolicyServer = $env:COMPUTERNAME,

    [Parameter(ParameterSetName = 'CLI', Mandatory = $true)]
    [String]
    $DataWarehouseName = 'StigMonitor',

    [Parameter(ParameterSetName = 'CLI')]
    [String]
    $CMSGroup,

    [Parameter(ParameterSetName = 'CLI', Mandatory = $true)]
    [String]
    $CustomerName,

    [Parameter(ParameterSetName = 'CLI', Mandatory = $true)]
    [String]
    $CustomerEmail,

    [Parameter(ParameterSetName = 'CLI', Mandatory = $true)]
    [Int]
    $NumberOfSQLInstances = 1,

    [Parameter(ParameterSetName = 'CLI')]
    [Switch]
    $Upgrade
)

# PSScriptRoot is not available when parsing default parameter values
if ([String]::IsNullOREmpty($SourceFile))
{
    $SourceFile =  [System.IO.Path]::Combine($PSScriptRoot, 'StigMonitor.bacpac')
}

# Determine whether this is a local or CMS installation
$IsLocal_1_or_0 = [String]::IsNullOrEmpty($CMSGroup) -as [int]

#region - Script Initialization
Write-Verbose -Message 'Begin script initialization'

Write-Verbose 'Locating SqlPackage'

# Path in which SqlPackage is located
$sqlPackageSearchPath = @(
    'C:\Program Files\Microsoft SQL Server'
    'C:\Program Files (x86)\Microsoft SQL Server'
)

Write-Verbose -Message 'Searching for SqlPackage binary'

$sqlPackagePath = Get-ChildItem -Path $sqlPackageSearchPath -Filter 'SqlPackage.exe' -Recurse -File |
    Sort-Object -Property FullName -Descending |
    Select-Object -First 1 -ExpandProperty FullName

if ($null -eq $sqlPackagePath)
{
    throw 'SqlPackage not found. Download from https://aka.ms/sqlpackage'
}

Write-Verbose "Found SqlPackage binary -> '$sqlPackagePath'"
#endregion

#region - Helper functions -
<#
    .SYNOPSIS
    Establishes a connection to a SQL Server instance

    .PARAMETER ServerName
    Name of the SQL Server to connect

    .PARAMETER InstanceName
    Name of the instance to connect (Default is 'MSSQLSERVER')

    .PARAMETER Database
    Name of the database to use on the SQL instance

    .PARAMETER Timeout
    Length of time (in seconds) to wait for a connection to the server before
    terminating the attempt and generating an error. (Default is 120)
#>
function Connect-SQL
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.String]
        $ServerName,

        [Parameter()]
        [System.String]
        $InstanceName = 'MSSQLSERVER',

        [Parameter()]
        [System.String]
        $Database,

        [Parameter()]
        [System.Int32]
        $Timeout = 120
    )

    if ($InstanceName -ne 'MSSQLSERVER')
    {
        Write-Verbose 'Appending instance name to server name'
        $ServerName += "\$InstanceName"
    }

    Write-Verbose 'Building connection string'
    $builder = New-Object System.Data.SqlClient.SqlConnectionStringBuilder

    # customize the connection string properties
    $builder['Data Source'] = $ServerName
    $builder['Application Name'] = 'PSDataHelper'
    $builder['Connect Timeout'] = $Timeout
    $builder['Trusted_Connection'] = $true

    # If a database was specified, use it
    if ($Database)
    {
        $builder['Initial Catalog'] = $Database
    }

    Write-Debug -Message $builder.ConnectionString

    # Initialize our object
    $sqlConnectionObject = New-Object System.Data.SqlClient.SqlConnection $builder.ConnectionString

    try
    {
        Write-Verbose "Opening connection to '$ServerName'"
        $sqlConnectionObject.Open()
    }
    catch
    {
        # TODO: Create a common error handler
        Write-Error -Message 'Error connecting to specified server.' -Exception $_.Exception

        # Null the connection object
        $sqlConnectionObject = $null
    }

    return $sqlConnectionObject
}

<#
    .SYNOPSIS
    Executes a stored procedure within a given database

    .PARAMETER Connection
    DbConnection object for the SQL Instance against which the command will
    execute.

    .PARAMETER DatabaseName
    The name of the database in which the command will run

    .PARAMETER ProcedureName
    String containing the name of the procedure to be executed.

    .PARAMETER QueryParameters
    Hashtable containing the names and values of all parameters for the
    stored procedure

    .PARAMETER CommandTimeout
    Length of time (in seconds) the query will be allowed to execute before
    terminating. Specifying zero (0) will allow the command to run indefinitely.
    (Default = 300)

    .PARAMETER WithResults
    Returns the resultset as a custom object.
#>
function Invoke-StoredProcedure
{
    [CmdletBinding()]
    [OutputType([Hashtable], ParameterSetName = 'WithResults')]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [System.Data.Common.DbConnection]
        $Connection,

        [Parameter()]
        [System.String]
        $DatabaseName,

        [Parameter()]
        [System.String]
        $ProcedureName,

        [Parameter()]
        [Alias("Parameters")]
        [Hashtable]
        $QueryParameters,

        [Parameter()]
        [int]
        $CommandTimeout = 300,

        [Parameter(ParameterSetName = 'WithResults')]
        [switch]
        $WithResults
    )

    # get a command object linked to the connection for querying
    $command = $Connection.CreateCommand()

    # set the type of the command to StoredProcedure
    $command.CommandType = "StoredProcedure"

    # set the command timeout value
    $command.CommandTimeout = $CommandTimeout

    # for stored procedures, only the procedure name is required
    $command.CommandText = $ProcedureName

    # apply the parameters to the procedure
    if ($QueryParameters.Keys.Count -gt 0)
    {
        # loop through each parameter passed
        foreach($key in $QueryParameters.Keys)
        {
            # add the parameter and its value
            $command.Parameters.AddWithValue($key, $QueryParameters[$key]) > $null
        }
    }

    try
    {
        $executeParams = @{
            Connection = $Connection
            Command = $command
            DatabaseName = $DatabaseName
            WithResults = $WithResults
        }

        # execute the procedure
        return ExecuteDbCommand @executeParams
    }
    catch
    {
        # re-throw the exception
        throw $_.Exception.ToString();
    }
    finally
    {
        # dispose of the .net objects created
        $command.Dispose()
    }
}

<#
    .SYNOPSIS
    Executes an ad-hoc SQL statement within a given database.

    .PARAMETER Connection
    DbConnection object for the SQL instance against which the command will
    execute.

    .PARAMETER DatabaseName
    The database in which the the SQL query will be executed.

    .PARAMETER QueryString
    String containing the T-SQL to be executed

    .PARAMETER QueryParameters
    Hashtable containing the names and values of all parameters for the query.

    .PARAMETER CommandTimeout
    Length of time (in seconds) the query will be allowed to execute before
    terminating. Specifying zero (0) will allow the command to run indefinitely.
    (Default = 300)

    .PARAMETER WithResults
    Returns the resultset as a custom object.
#>
function Invoke-SqlQuery
{
    [CmdletBinding()]
    [OutputType('Hashtable', ParameterSetName = 'WithResults')]
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [System.Data.Common.DbConnection]
        $Connection,

        [Parameter(Mandatory = $true)]
        [System.String]
        $DatabaseName,

        [Parameter(Mandatory = $true)]
        [System.String]
        $QueryString,

        [Parameter()]
        [Alias("Parameters")]
        [Hashtable]
        $QueryParameters,

        [Parameter()]
        [Int]
        $CommandTimeout = 300,

        [Parameter(ParameterSetName = 'WithResults')]
        [Switch]
        $WithResults
    )

    # create a command for executing
    $command = $Connection.CreateCommand()

    # mark this as an ad-hoc query
    $command.CommandType = "Text"

    # set the timeout for the command
    $command.CommandTimeout = $CommandTimeout

    # attach the query string
    $command.CommandText = $QueryString

    # determine whether any parameter attachment is required
    if ($QueryParameters.Keys.Count -gt 0)
    {
        # loop over the keys
        foreach($key in $QueryParameters.Keys)
        {
            # add the parameter to the command's parameters
            $command.Parameters.AddWithValue($key, $QueryParameters[$key]) > $null
        }
    }

    try
    {
        $executeParams = @{
            Connection = $Connection
            Command = $Command
            DatabaseName = $DatabaseName
            WithResults = $WithResults
        }
        # execute the query
        return ExecuteDbCommand @executeParams
    }
    catch
    {
        # rethrow exception
        throw $_.Exception.ToString()
    }
    finally
    {
        # dispose of the .net objects created
        $command.Dispose()
    }
}

<#
    .SYNOPSIS
    Executes a command against a database connection

    .DESCRIPTION
    Executes the specified DbCommand against the DbConnection, optionally
    returning the results.

    .PARAMETER Connection
    Database connection to use for execution

    .PARAMETER Command
    DbCommand instance containing the command to be executed

    .PARAMETER WithResults
    Switch determinng whether a resultset from the procedure is returned.

    .EXAMPLE
    ExecuteDbCommand -Connection $Connection -Command $Command
#>
function ExecuteDbCommand
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.Data.Common.DbConnection]
        $Connection,

        [Parameter(Mandatory = $true)]
        [System.String]
        $DatabaseName,

        [Parameter(Mandatory = $true)]
        [System.Data.Common.DbCommand]
        $Command,

        [Parameter()]
        [Switch]
        $WithResults
    )

    try
    {
        # execute the procedure from within the requested database
        $Connection.ChangeDatabase($DatabaseName)

        # determines whether a resultset is required
        if ( $WithResults )
        {
            # array to store the results
            $resultSet = @()

            # execute the query and return the results
            $reader = $Command.ExecuteReader()

            # parse the output into a custom object
            try
            {
                while ($reader.Read())
                {
                    # create a new hashtable to represent this row
                    $rowHashTable = @{}

                    # loop through the columns
                    for( $i = 0; $i -lt $reader.VisibleFieldCount; $i++ )
                    {
                        # get the field name
                        $key = $reader.GetName($i)

                        # If the column has no name (or alias)
                        if ([String]::IsNullOrEmpty($key))
                        {
                            # Create our own based on the index
                            $key = "Unnamed_Column_$i"
                        }

                        # get the value
                        $value = $reader[$i]

                        # add the column to our row
                        $rowHashTable += @{ $key = $value }
                    }

                    # append the new object to the resultset
                    $resultSet += New-Object PSObject -Property $rowHashTable
                }

                # close the reader
                $reader.Close()

                # Return the results
                return $resultSet
            }
            catch
            {
                # re-throw the exception
                throw $_.Exception.ToString()
            }
            finally
            {
                $reader.Dispose()
            }
        }
        else
        {
            # just execute, returning nothing
            $null = $Command.ExecuteNonQuery()
        }
    }
    catch
    {
        # re-throw the exception
        throw $_.Exception.ToString();
    }
    finally
    {
        # dispose of the .net objects created
        $Command.Dispose()
    }
}

<#
    .SYNOPSIS
    Tests whether a given STIG Monitor database exists on a server.

    .PARAMETER ServerName
    Name of the policy server.

    .PARAMETER DatabaseName
    Name of the STIG Monitor database to test. (Default is 'StigMonitor')
#>
function Test-PolicyDatabase
{
    [OutputType('System.Boolean')]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.String]
        $ServerName,

        [Parameter()]
        [System.String]
        $DatabaseName = 'StigMonitor'
    )

    Write-Verbose -Message "Checking whether database '$DatabaseName' exists on instance '$Servername'."

    # Get a Connection to the SQL Server
    Write-Verbose -Message "Connecting to '$ServerName'."

    # Support named instance
    $ServerName, $InstanceName = $ServerName.Split('\')

    # Attempt a connection to the server
    $serverConnection = Connect-SQL -ServerName $ServerName -InstanceName $InstanceName -Timeout 5

    if ($null -ne $serverConnection)
    {
        Write-Verbose 'Policy server found, gathering information.'

        try
        {
            $queryParameters = @{
                Connection = $serverConnection
                QueryString = 'SELECT COUNT(*) AS databaseCount FROM sys.databases WHERE name = @PolicyDatabase'
                DatabaseName = 'master'
                QueryParameters = @{
                    '@PolicyDatabase' = $DatabaseName
                }
            }

            $queryResult = Invoke-SqlQuery @queryParameters -WithResults

            return ($queryResult.databaseCount -eq 1)
        }
        catch
        {
            Write-Warning "Error locating database '$DatabaseName'. Please ensure the PolicyServer is online and accessible."
            return $false
        }
    }

    return $false
}

<#
    .SYNOPSIS
    Loads STIG Monitor configuration information from an existing database.

    .PARAMETER ServerName
    Name of the policy server.

    .PARAMETER DatabaseName
    Name of the STIG Montitor database to load. (Default is 'StigMonitor')
#>
function Get-ExistingConfiguration
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        [System.String]
        $ServerName,

        [Parameter()]
        [System.String]
        $DatabaseName = 'StigMonitor'
    )

    # Split named server into its components
    $ServerName, $InstanceName = $ServerName.Split('\')

    # Connect to the Policy Server
    $policyServer = Connect-SQL -ServerName $ServerName -InstanceName $InstanceName -Database $DatabaseName

    # Splat the parameters for our query
    $queryParameters = @{
        Connection = $policyServer
        DatabaseName = $DatabaseName
        QueryString = "SELECT STIG.fn_Param('IsLocal') AS IsLocal,
            STIG.fn_Param('CMSGroup') AS CMSGroup,
            STIG.fn_Param('NumberOfSQLServers') AS NumberOfSQLServers,
            STIG.fn_Param('LicenseUser') AS LicenseUser,
            STIG.fn_Param('CustomerEmail') AS CustomerEmail,
            STIG.fn_Param('PowerShellPath') AS InstallPath"
        WithResults = $true
    }

    # Execute the query
    $configuration = Invoke-SqlQuery @queryParameters

    # Pass the configuration back to the caller
    return $configuration
}
#endregion

# If no commandline options were specified, display the GUI
if ($PSCmdlet.ParameterSetName -eq 'GUI')
{
    Write-Verbose 'Displaying user interface...'

    # Create an object containing the configuration data provided by the user
    $userSettings = New-Object -TypeName PSObject -Property @{
        SourceFile = $SourceFile
        InstallPath = $InstallPath
        PolicyServer = $PolicyServer
        IsUpgrade = $Upgrade
        DatawarehouseName = $DataWarehouseName
        CMSGroup = $CMSGroup
        IsLocalInstall = $IsLocal_1_or_0 -as [bool]
        CustomerName = $CustomerName
        CustomerEmail = $CustomerEmail
        NumberOfSQLInstances = $NumberOfSQLInstances
        InitiateInstall = $false
    }

    # Create a method to validate the settings specified
    $userSettings | Add-Member -MemberType ScriptMethod -Name Validate -Value {
        $stateValid = $true

        if ($false -eq (Test-Path -Path $this.SourceFile -PathType Leaf))
        {
            $stateValid = $false
            Write-Warning -Message "Cannot find source file!"
            $SourceFile.BorderBrush = 'Red'
        }

        $server, $instance = $this.PolicyServer.Split('\')

        if ($null -eq (Connect-SQL -ServerName $server -InstanceName $instance -Timeout 5 -ErrorAction SilentlyContinue))
        {
            $stateValid = $false
            Write-Warning -Message 'Policy server is not accessible or offline.'
            $PolicyServer.BorderBrush = 'Red'
        }

        # Not a local install, make sure CMS group name is specified
        if ($false -eq $this.IsLocalInstall)
        {
            if ([String]::IsNullOrEmpty($this.CMSGroup))
            {
                $stateValid = $true
                Write-Warning -Message 'CMS Group cannot be empty.'
                $CMSGroupName.BorderBrush = 'Red'
            }
        }

        if ([String]::IsNullOrEmpty($this.CustomerName))
        {
            $stateValid = $false
            Write-Warning -Message 'Customer Name cannot be empty.'
            $CustomerName.BorderBrush = 'Red'
        }

        if ([String]::IsNullOrEmpty($this.CustomerEmail))
        {
            $stateValid = $false
            Write-Warning -Message 'Customer Email cannot be empty.'
            $CustomerEmail.BorderBrush = 'Red'
        }

        if ($false -eq [Int32]::TryParse($userSettings.NumberOfSQLInstances, [ref]$null))
        {
            $stateValid = $false
            Write-Warning 'Number of SQL instances is invalid.'
            $InstanceCount.BorderBrush = 'Red'
        }

        return $stateValid
    }

    # Import the WPF assembly
    Add-Type –AssemblyName PresentationFramework
    Add-Type -AssemblyName System.Windows.Forms

    # Define the XAML for the form
    [xml]$xaml = '
        <Window
            xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
            xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
            xmlns:d="http://schemas.microsoft.com/expression/blend/2008"
            xmlns:local="clr-namespace:SqlStigInstaller"
            Title="SQL STIG Monitor Installer" Height="325" Width="600" ResizeMode="NoResize">
        <Grid>
            <TextBlock HorizontalAlignment="Left" Height="16" Margin= "10,60,0,0" TextWrapping="Wrap" Text="Source Bacpac File: " VerticalAlignment="Top" Width="140" FontWeight="Bold"/>
            <TextBlock HorizontalAlignment="Left" Height="16" Margin= "10,80,0,0" TextWrapping="Wrap" Text="Install Path:" VerticalAlignment="Top" Width="140" FontWeight="Bold"/>
            <TextBlock HorizontalAlignment="Left" Height="16" Margin="10,100,0,0" TextWrapping="Wrap" Text="Policy Server:" VerticalAlignment="Top" Width="140" FontWeight="Bold"/>
            <TextBlock HorizontalAlignment="Left" Height="16" Margin="10,120,0,0" TextWrapping="Wrap" Text="Database Name:" VerticalAlignment="Top" Width="140" FontWeight="Bold"/>
            <TextBlock HorizontalAlignment="Left" Height="16" Margin="10,140,0,0" TextWrapping="Wrap" Text="Upgrade Existing:" VerticalAlignment="Top" Width="140" FontWeight="Bold"/>
            <TextBlock HorizontalAlignment="Left" Height="16" Margin="10,160,0,0" TextWrapping="Wrap" Text="Local Install:" VerticalAlignment="Top" Width="140" FontWeight="Bold"/>
            <TextBlock HorizontalAlignment="Left" Height="16" Margin="10,180,0,0" TextWrapping="Wrap" Text="CMS Group:" VerticalAlignment="Top" Width="140" FontWeight="Bold"/>
            <TextBlock HorizontalAlignment="Left" Height="16" Margin="10,200,0,0" TextWrapping="Wrap" Text="Customer Name:" VerticalAlignment="Top" Width="140" FontWeight="Bold"/>
            <TextBlock HorizontalAlignment="Left" Height="16" Margin="10,220,0,0" TextWrapping="Wrap" Text="Customer Email:" VerticalAlignment="Top" Width="140" FontWeight="Bold"/>
            <TextBlock HorizontalAlignment="Left" Height="16" Margin="10,240,0,0" TextWrapping="Wrap" Text="SQL Instances:" VerticalAlignment="Top" Width="140" FontWeight="Bold"/>

            <TextBox x:Name="SourceFile" HorizontalAlignment="Left" Height="16"    Margin="155,60,0,0" Text="{Binding SourceFile}" VerticalAlignment="Top" Width="350" FontSize="10" ToolTipService.ToolTip="Path to the bacpac file"/>
            <TextBox x:Name="InstallPath"  HorizontalAlignment="Left" Height="16"  Margin="155,80,0,0" Text="{Binding InstallPath}" VerticalAlignment="Top" Width="350" FontSize="10" ToolTipService.ToolTip="Path where the files will be copied"/>
            <TextBox x:Name="PolicyServer" HorizontalAlignment="Left" Height="16"  Margin="155,100,0,0" Text="{Binding PolicyServer}" VerticalAlignment="Top" Width="350" FontSize="10" ToolTipService.ToolTip="Server\Instance to install; just use Server for default instances"/>
            <TextBox x:Name="DatabaseName" HorizontalAlignment="Left" Height="16"  Margin="155,120,0,0" Text="{Binding DatawarehouseName}" VerticalAlignment="Top" Width="350" FontSize="10" ToolTipService.ToolTip="Database name to be created"/>
            <CheckBox x:Name="IsUpgrade" HorizontalAlignment="Left"                Margin="155,140,0,0" VerticalAlignment="Top" ToolTipService.ToolTip="Check if overwriting an existing installation."/>
            <CheckBox x:Name="IsLocalInstall" HorizontalAlignment="Left"           Margin="155,160,0,0" VerticalAlignment="Top" IsChecked="{Binding IsLocalInstall}" ToolTipService.ToolTip="Uncheck if using a CMS"/>
            <TextBox x:Name="CMSGroupName" HorizontalAlignment="Left" Height="16"  Margin="155,180,0,0" Text="{Binding CMSGroup}" VerticalAlignment="Top" Width="350" FontSize="10" ToolTipService.ToolTip="Name of CMS registered group"/>
            <TextBox x:Name="CustomerName" HorizontalAlignment="Left" Height="16"  Margin="155,200,0,0" Text="{Binding CustomerName}" VerticalAlignment="Top" Width="350" FontSize="10" ToolTipService.ToolTip="Civilian contact name for updates"/>
            <TextBox x:Name="CustomerEmail" HorizontalAlignment="Left" Height="16" Margin="155,220,0,0" Text="{Binding CustomerEmail}" VerticalAlignment="Top" Width="350" FontSize="10" ToolTipService.ToolTip="Email address of contact"/>
            <TextBox x:Name="InstanceCount" HorizontalAlignment="Left" Height="16" Margin="155,240,0,0" Text="{Binding NumberOfSQLInstances}" VerticalAlignment="Top" Width="30" FontSize="10" ToolTipService.ToolTip="Estimated # of instances supported"/>

            <TextBlock HorizontalAlignment="Left" Height="45" Margin="10,10,0,0" TextWrapping="Wrap" VerticalAlignment="Top" Width="500" FontSize="10">
                <Run FontWeight="Bold" Text="To run the installation of the bacpac and copy files, complete the fields below and select INSTALL."/>
                <LineBreak/>
                <Run Text="This only needs to be performed on one server if using a Central Management Server (CMS)."/>
            </TextBlock>

            <Button x:Name="bBrowseSource"  FontSize="10" Content="Browse" HorizontalAlignment="Center" Height="17" Margin="490,59,0,0" VerticalAlignment="Top" Width="60"/>
            <Button x:Name="bBrowseInstall" FontSize="10" Content="Browse" HorizontalAlignment="Center" Height="17" Margin="490,79,0,0" VerticalAlignment="Top" Width="60"/>
            <Button x:Name="bInstall" Content="INSTALL" HorizontalAlignment="Center" Height="30" Margin="0,0,0,10" VerticalAlignment="Bottom" Width="100"/>
        </Grid>
    </Window>'

    # Initialize an XML reader to parse the XAML document
    $xamlReader = New-Object -TypeName System.Xml.XmlNodeReader -ArgumentList $xaml

    # Create a window from the XAML document
    $window = [System.Windows.Markup.XamlReader]::Load($xamlReader)

    # Create a variable for all XAML form objects
    $xaml.SelectNodes("//*[@*[contains(translate(name(.),'n','N'),'Name')]]") |
        ForEach-Object -Process { New-Variable -Name $_.Name -Value $Window.FindName($_.Name) -Force }

    # Bind the form to our custom object
    $window.DataContext = $userSettings

    #region Event handlers for button clicks
    # Browse for BACPAC
    $window.FindName('bBrowseSource').Add_click({
        $fileBrowser = New-Object -TypeName Microsoft.Win32.OpenFileDialog
        $fileBrowser.Multiselect = $false
        $fileBrowser.Filter = 'BACPAC (*.bacpac)|*.bacpac|All Files (*.*)|*.*'
        $fileBrowser.FileName = $window.DataContext.SourceFile

        if ($fileBrowser.ShowDialog() -eq 'OK')
        {
            $userSettings.SourceFile = $fileBrowser.FileName

            # TODO: Convert to ObservableCollection<T>
            $window.DataContext = $null
            $window.DataContext = $userSettings
        }
    })

    # Browse for install path
    $window.FindName('bBrowseInstall').Add_click({
        $folderBrowser = New-Object -TypeName System.Windows.Forms.FolderBrowserDialog
        $folderBrowser.RootFolder = 'MyComputer'
        $folderBrowser.ShowNewFolderButton = $true
        $folderBrowser.SelectedPath = $window.DataContext.InstallPath

        if ($folderBrowser.ShowDialog() -eq 'OK')
        {
            $userSettings.InstallPath = $folderBrowser.SelectedPath

            # TODO: Convert to ObservableCollection<T>
            $window.DataContext = $null
            $window.DataContext = $userSettings
        }
    })

    # Initiate the install
    $window.FindName('bInstall').Add_click({
        # $userSettings.InitiateInstall = $true
        if ($userSettings.Validate())
        {
            $window.DialogResult = $true
            $window.Close()
        }
    })

    # When a CMS group name is typed, unflag IsLocalInstall
    $window.FindName('CMSGroupName').Add_textChanged({
        # Update the checked state based on whether a CMS group value is specified
        $checkedState = [String]::IsNullOrWhiteSpace($this.Text)
        $userSettings.IsLocalInstall = $checkedState
        $window.FindName('IsLocalInstall').IsChecked = $checkedState
    })

    # When the user flags the local install check
    $window.FindName('IsLocalInstall').Add_checked({
        $cmsTextBox = $window.FindName('CMSGroupName')

        # If the textbox is just whitespace characters, wipe it
        if ($cmsTextBox.Text -match '^\s+$') {
            $cmsTextBox.Text = [String]::Empty
        }

        $cmsTextBox.IsEnabled = $false
    })

    # When the user unflags the local install check
    $window.FindName('IsLocalInstall').Add_unchecked({
        $cmsTextBox = $window.FindName('CMSGroupName')
        $cmsTextBox.IsEnabled = $true
    })

    # When the user flags the Upgrade checkbox, check for backup and if database exists
    $window.FindName('IsUpgrade').Add_checked({
        Write-Host $IsUpgrade.Checked

        $testResult = Test-PolicyDatabase -ServerName $userSettings.PolicyServer -DatabaseName $userSettings.DatawarehouseName

        if ($false -eq $testResult)
        {
            # Build the message to be displayed
            $warningMessage = "Database '$($userSettings.DatawarehouseName) does not exist on Policy Server '$($userSettings.PolicyServer). Verify the database and policy server names before continuing."

            # Show the message to the user and in the console
            Write-Warning -Message $warningMessage
            [System.Windows.MessageBox]::Show($window, $warningMessage, 'Database Not Found!', 'OK','Warning')

            # Unflag the checkbox
            $this.IsChecked = $false
        }
        else
        {
            # Get the remaining configuration options from the Policy Server
            $configuration = Get-ExistingConfiguration -ServerName $userSettings.PolicyServer -DatabaseName $userSettings.DatawarehouseName

            <#
                Settings are stored as string representations. Convert to an int (should be 1 or 0),
                then convert the value from int to boolean so the checkbox binding works properly.
            #>
            $userSettings.IsLocalInstall = ($configuration.IsLocal -as [int]) -as [bool]
            
            # If this is not a local install, update the CMS Server
            if ($false -eq $userSettings.IsLocalInstall)
            {
                $userSettings.CMSGroup = $configuration.CMSGroup
            }

            $userSettings.CustomerName = $configuration.LicenseUser
            $userSettings.CustomerEmail = $configuration.CustomerEmail
            $userSettings.NumberOfSQLInstances = $configuration.NumberOfSQLServers -as [int]
            $userSettings.InstallPath = $configuration.InstallPath

            # TODO: Convert to ObservableCollection<T>
            $window.DataContext = $null
            $window.DataContext = $userSettings
        }
    })
    #endregion

    # Display the GUI
    $dialogResult = $window.ShowDialog()

    # Expand user selected settings back to variables for use during installation
    $SourceFile = Get-Item -Path $userSettings.SourceFile -ErrorAction SilentlyContinue
    $InstallPath = $userSettings.InstallPath
    $PolicyServer = $userSettings.PolicyServer
    $DataWarehouseName = $userSettings.DatawarehouseName
    $CMSGroup = $userSettings.CMSGroup
    $IsLocal_1_or_0 = 0

    # If this is a local install, remove the CMSGroup and tag it for local
    if ($userSettings.IsLocalInstall)
    {
        Remove-Variable -Name CMSGroup
        $IsLocal_1_or_0 = 1
    }

    $CustomerName = $userSettings.CustomerName
    $CustomerEmail = $userSettings.CustomerEmail
    $NumberOfSQLInstances = $userSettings.NumberOfSQLInstances
    $InitiateInstall = $dialogResult
    $Upgrade = $IsUpgrade.IsChecked
}

if ($false -eq $InitiateInstall)
{
    throw 'User cancelled installation process.'
}

# Used to mark that specific steps have completed.
$databaseDeployed = $false
$scriptsDeployed = $False

#region Pre-Upgrade Work
if ($Upgrade)
{
    Write-Host 'Begin pre-upgrade process...'

    # Ensure we don't try to install if this section falls over
    $InitiateInstall = $false

    # Check whether we have an existing connection to the policy server
    if ($null -eq $script:policyServerConnection)
    {
        Write-Verbose "Existing database connection not found. Connecting to policy server '$PolicyServer'"

        # Connect to the Policy Server
        $script:policyServerConnection = Connect-SQL -ServerName $PolicyServer -Database $DataWarehouseName
    }

    # Verify whether the specified database exists on the policy server
    if (Test-PolicyDatabase -ServerName $PolicyServer -DatabaseName $DataWarehouseName)
    {
        Write-Host 'Extracting existing information...'

        try
        {
            # Migrate existing data out of the database
            $migrateProcedureParameters = @{
                Connection = $script:policyServerConnection
                DatabaseName = $DataWarehouseName
                ProcedureName = 'STIG.usp_sysMigrateData'
                Parameters = @{ '@Stage' = 'PreMigration' }
                CommandTimeout = 0
            }

            Write-Verbose 'Exporting Findings, approvals, and comments'
            Invoke-StoredProcedure @migrateProcedureParameters

            $migrateConfigurationParameters = @{
                Connection = $script:policyServerConnection
                DatabaseName = $DataWarehouseName
                QueryString = "IF OBJECT_ID('TEMPDB.dbo.TEMP_STIG_ConfigSettings') IS NOT NULL
                    DROP TABLE TEMPDB.dbo.TEMP_STIG_ConfigSettings
                    SELECT ParameterName, ParameterValue, IsEnabled, Comments
                    INTO TEMPDB.dbo.TEMP_STIG_ConfigSettings
                    FROM STIG.ConfigParameter
                    WHERE ParameterName NOT in('xxSTIGDWVersion','xxReportVersion') "
                CommandTimeout = 0
            }

            Write-Verbose 'Exporting Configuration Values'
            Invoke-SqlQuery @migrateConfigurationParameters
        }
        catch
        {
            throw 'An error occurred while migrating data. Aborting process.'
            exit 2
        }

        Write-Host "Dropping database '$DataWarehouseName'..."
        $dropDatabaseParameters = @{
            Connection = $script:policyServerConnection
            DatabaseName = 'master'
            QueryString = "ALTER DATABASE [$DataWarehouseName] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE [$DataWarehouseName]"
        }

        Invoke-SqlQuery @dropDatabaseParameters

        Write-Verbose "Disconnecting from Policy Server..."
        $script:policyServerConnection.Close()
        $script:policyServerConnection.Dispose()

        Remove-Variable -Name 'policyServerConnection' -Scope 'Script'

        Write-Host 'Finish pre-migration process.'
        $InitiateInstall = $true
    }
    else
    {
        throw "Cannot find database '$DataWarehouseName' on server '$PolicyServer'"
        exit 2
    }
}
#endregion

# region Deploy database
if ($InitiateInstall)
{
    # Make sure nothing changed
    if ($false -eq (Test-Path -Path $sqlPackagePath -PathType Leaf -ErrorAction SilentlyContinue))
    {
        throw 'SqlPackage not found. Download from https://aka.ms/sqlpackage'
    }

    # Build an array of parameters for SqlPackage
    $deploymentParameters = @(
        '/Action:Import'
        '/Quiet:True'
        ('/SourceFile:"{0}"' -f $SourceFile.FullName)
        ('/TargetServerName:"{0}"' -f $PolicyServer)
        ('/TargetDatabaseName:"{0}"' -f $DataWarehouseName)
        '/TargetTimeout:120'
    )

    Write-Verbose 'Deploying the BACPAC'
    Write-Debug "Parameters: $($deploymentParameters -join ' ')"

    # Define how to run SqlPackage including error/output redirection
    $deploySettings = New-Object System.Diagnostics.ProcessStartInfo
    $deploySettings.FileName = $sqlPackagePath
    $deploySettings.Arguments = ($deploymentParameters -join ' ')
    $deploySettings.CreateNoWindow = $true
    $deploySettings.UseShellExecute = $false
    $deploySettings.RedirectStandardError = $true
    $deploySettings.RedirectStandardOutput = $true

    # Start the process and wait for it to complete.
    $deployProcess = New-Object System.Diagnostics.Process 
    $deployProcess.StartInfo = $deploySettings

    Write-Debug 'Waiting for sqlpackage.exe process to exit...'
    if ($deployProcess.Start())
    {
        # Continually read the StandardOutput stream and write lines to verbose output.
        while ($deployProcess.HasExited -eq $false)
        {
            while ($null -ne ($outputLine = $deployProcess.StandardOutput.ReadLine()))
            {
                Write-Verbose -Message $outputLine
            }
        }

        Write-Debug "SqlPackage exit code = $($deployProcess.ExitCode)"

        if ($deployProcess.ExitCode -ne 0)
        {
            # Read the error stream and break into individual errors trapped
            $deployErrors = $deployProcess.StandardError.ReadToEnd() -split '\r\n\r\n'

            foreach ($deployError in $deployErrors)
            {
                Write-Error -Message $deployError -Category FromStdErr
            }

            throw "Unable to deploy STIG Monitor database. Correct any errors reported and restart the process."
        }
    }

    $databaseDeployed = $true
}
else
{
    throw 'Installation cancelled due to an error. Review messages above and correct any issues reported before retrying.'
}
#endregion

#region Post-Upgrade Work
if ($Upgrade -and $databaseDeployed)
{
    Write-Host 'Begin post-upgrade process...'

    # Check whether we have an existing connection to the policy server
    if ($null -eq $script:policyServerConnection)
    {
        Write-Verbose "Existing database connection not found. Connecting to policy server '$PolicyServer'"

        # Connect to the Policy Server
        $script:policyServerConnection = Connect-SQL -ServerName $PolicyServer -Database $DataWarehouseName
    }

    # Migrate existing data out of the database
    Write-Host 'Importing extracted information...'

    $migrateConfigurationParameters = @{
        Connection = $script:policyServerConnection
        DatabaseName = $DataWarehouseName
        QueryString = 'UPDATE s
SET ParameterValue = a.ParameterValue, IsEnabled = a.IsEnabled
FROM TEMPDB.dbo.TEMP_STIG_ConfigSettings a
JOIN STIG.ConfigParameter s ON s.ParameterName = a.ParameterName
WHERE s.ParameterName NOT in (''STIGDWVersion'',''ReportVersion''); '
    }

    Write-Verbose 'Importing Configuration values.'
    Invoke-SqlQuery @migrateConfigurationParameters

    $migrateProcedureParameters = @{
        Connection = $script:policyServerConnection
        DatabaseName = $DataWarehouseName
        ProcedureName = 'STIG.usp_sysMigrateData'
        Parameters = @{ '@Stage' = 'PostMigration' }
        CommandTimeout = 0
    }

    Write-Verbose 'Importing Findings, approvals, and comments'
    Invoke-StoredProcedure @migrateProcedureParameters
}
#endregion

if ($databaseDeployed)
{
    Write-Host 'Begin script deployment...'
    Write-Debug -Message 'Loading compression libraries.'

    # Import the .NET Compression classes
    Add-Type -AssemblyName 'System.IO.Compression, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089' -ErrorAction Stop
    Add-Type -AssemblyName 'System.IO.Compression.FileSystem, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089' -ErrorAction Stop

    # Create the root installation directory if it does not already exist
    if (-not (Test-Path -Path $InstallPath -PathType Container))
    {
        Write-Verbose -Message "Creating installation path: $InstallPath"
        New-Item -Path $InstallPath -ItemType Directory -Force -ErrorAction Stop > $null
    }

    Write-Verbose -Message 'Opening deployment package'
    # Open a stream to the BACPAC file
    $bacpacStream = New-Object System.IO.FileStream $SourceFile.FullName, 'Open'

    try
    {
        # ZipArchive to allow for reading the BACPAC contents
        $bacpacArchive = New-Object System.IO.Compression.ZipArchive $bacpacStream, 'Read'

        try
        {           
            # Manifest will be extracted to a temporary file for processing
            $manifestTempFile = [System.IO.Path]::GetTempFileName()
            $manifestEntry = $bacpacArchive.GetEntry('Manifest.xml')

            # Ensure we have a manifest describing what to extract
            if ($null -ne $manifestEntry)
            {
                # Extract the Manifest to a temporary location
                [System.IO.Compression.ZipFileExtensions]::ExtractToFile($manifestEntry, $manifestTempFile, $true) > $null

                # Read the manifest into an object
                $manifest = Import-Clixml -Path $manifestTempFile -ErrorAction Stop

                # Delete the temporary Manifest file
                Remove-Item -Path $manifestTempFile -Force -ErrorAction SilentlyContinue > $null

                Write-Host 'Deploying files'

                # Extract files to disk
                foreach($file in $manifest.Files.GetEnumerator())
                {
                    $targetFolder = $file.Target.Replace('{InstallPath}', $InstallPath)
                    $targetFileName = [System.IO.Path]::GetFileName($file.EntryName)
                    $targetFilePath = Join-Path -Path $targetFolder -ChildPath $targetFileName

                    # Ensure the target folder exists
                    if (-not (Test-Path -Path $targetFolder -PathType Container))
                    {
                        Write-Verbose " > Creating directory '$targetFolder'"
                        New-Item -Path $targetFolder -ItemType Directory -Force -ErrorAction Stop > $null
                    }

                    # Extract the file
                    Write-Verbose " >> Extracting '$targetFilePath'"

                    try
                    {
                        $fileEntry = $bacpacArchive.GetEntry($file.EntryName)
                        [System.IO.Compression.ZipFileExtensions]::ExtractToFile($fileEntry, $targetFilePath, $true) > $null
                    }
                    catch {
                        Write-Error $_.ToString()
                        throw
                    }

                    # Get the hash for the extracted file
                    $checksum = Get-FileHash -Path $targetFilePath -Algorithm SHA256

                    # Determine whether the checksum is a match
                    if ($checksum.Hash -ne $file.Checksum)
                    {
                        Write-Warning -Message "Bad Checksum => $targetFilePath"
                        Remove-Item -Path $targetFilePath -Force -ErrorAction SilentlyContinue
                    }

                    Write-Host " > $targetFilePath"
                }
            }
            else 
            {
                Write-Error `
                    -Message 'An error occurred while deploying scripts. The package may be corrupt or incomplete.' `
                    -Category InvalidOperation
            }

            # Signal that the scripts have been successfully deployed
            $scriptsDeployed = $true

            Write-Host 'End Script Deployment'
        }
        finally
        {
            $bacpacArchive.Dispose()
        }
    }
    finally
    {
        $bacpacStream.Dispose()
    }

    # Unblock all files that were deployed
    Write-Verbose 'Unblocking all installed files.'
    Get-ChildItem -Path $InstallPath -Recurse | Unblock-File 
}

if ($databaseDeployed -and $scriptsDeployed)
{
    Write-Host 'Begin database configuration...'
    if ($null -eq $script:policyServerConnection)
    {
        Write-Verbose 'Connecting to policy server...'
        $script:policyServerConnection = Connect-SQL -ServerName $PolicyServer -Database $DataWarehouseName
    }

    $baseParameterSet = @{
        Connection = $script:policyServerConnection
        Database = $DataWarehouseName
    }

    # Configure the synonyms on this instance
    Write-Host ' > Creating synonyms'
    Invoke-StoredProcedure @baseParameterSet -ProcedureName 'STIG.usp_sysBuildSynonym'

    Write-Host ' > Updating configuration parameters'
    Invoke-StoredProcedure @baseParameterSet -ProcedureName 'STIG.usp_sysSetConfigParameters'

    Write-Host ' > Generate the CMS Function'
    Invoke-StoredProcedure @baseParameterSet -ProcedureName 'STIG.usp_sysCreateCMSFunction'

    # TODO: If "IsLocal_1_or_0" is 1, do not add "CMSServer"
    $configurationValues = @{
        PowerShellPath = $InstallPath
        CMSGroup = $CMSGroup
        CMSServer = $PolicyServer
        DWNames = $DataWarehouseName
        IsLocal = $IsLocal_1_or_0
        LicenseUser = $CustomerName
        CustomerEmail = $CustomerEmail
        NumberOfSQLServers = $NumberOfSQLInstances
    }

    Write-Host 'Registering configuration options...'
    foreach ($configParameter in $configurationValues.GetEnumerator())
    {
        $updateConfigParameters = $baseParameterSet.Clone()

        if ($null -eq $configParameter.Value)
        {
            $configParameter.Value = [String]::Empty
        }

        $updateConfigParameters += @{
            QueryString = 'UPDATE STIG.ConfigParameter SET ParameterValue = @ConfigValue WHERE ParameterName = @ConfigParameter;'
            QueryParameters = @{
                '@ConfigParameter' = $configParameter.Key
                '@ConfigValue' = $configParameter.Value
            }
        }

        Write-Host " + $($configParameter.Key)"
        Invoke-SqlQuery @updateConfigParameters
    }

    # Create the SQL Agent Proxy account
    Write-Host ' > Creating Proxy'
    Invoke-StoredProcedure @baseParameterSet -ProcedureName 'STIG.usp_sysCreateProxy'

    # Create the initial SQL Agent job for checking compliance
    Write-Host ' > Creating SQL Agent job'
    Invoke-StoredProcedure @baseParameterSet -ProcedureName 'STIG.usp_sysBuildSQLAgentJob'

    Write-Host ' > Checking licensing state'
    $licenseStatus = Invoke-SqlQuery @baseParameterSet -QueryString "SELECT IsActivated = STIG.fn_License(STIG.fn_Param('LicenseUser'))" -WithResults

    if ($licenseStatus.IsActivated -eq 0) {
        Write-Debug "LicenseStatus->IsActivated = $($licenseStatus.IsActivated)"

        # Create LicenseKey Challenge value
        Write-Host ' > Product requires activation.'
        Invoke-StoredProcedure @baseParameterSet -ProcedureName 'STIG.ActivateLicense'

        # Retrieve the registration information required to activate the installation
        $registrationQueryParameters = $baseParameterSet.Clone()
        $registrationQueryParameters += @{
            QueryString = 'SELECT STIG.fn_Object() AS Challenge, STIG.fn_Server() AS EncryptionKey, STIG.fn_Param(@VersionParam) AS DWVersion'
            QueryParameters = @{ '@VersionParam' = 'STIGDWVersion' }
            WithResults = $true
        }

        # Execute the query to collection registration information
        $registrationInfo = Invoke-SqlQuery @registrationQueryParameters

        # Write-Host "Log into https://aka.ms/STIGMonitor to generate a License Key"  -ForegroundColor Yellow
        # Write-Host "using the key information below."  -ForegroundColor Yellow
        Write-Host ''
        Write-Host 'Please e-mail [STIGMonitor@microsoft.com] the following information for a FREE License Key' -ForegroundColor Yellow
        Write-Host '=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-='
        Write-Host "Customer/Org Name      : $CustomerName"  -ForegroundColor Green
        Write-Host "License Key Challenge  : $($registrationInfo.Challenge)"  -ForegroundColor Green
        Write-Host "Encryption Key Value   : $($registrationInfo.EncryptionKey)"  -ForegroundColor Green
        Write-Host "Customer Email Address : $CustomerEmail"  -ForegroundColor Green
        Write-Host "Number of SQL Instances: $NumberOfSQLInstances"  -ForegroundColor Green
        Write-Host "STIGMonitor Version    : $($registrationInfo.DWVersion)"  -ForegroundColor Green
        Write-Host '=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-='
        Write-Host "You will receive a FREE License Key and instructions for full functionality."  -ForegroundColor Yellow
        Write-Host "If you have any questions, please e-mail STIGMonitor@microsoft.com"  -ForegroundColor Yellow
    }
}

Write-Host ''
Write-Host '*** Installation Complete ***'

if (-not $psISE)
{
    Write-Host ''
    Write-Host 'Press any key to continue...'

    # Await a keypress
    $null = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}
