﻿# -------------------------------------------------------------------------------------
# Author:      Brandon Adams, Microsoft
# Date:        08 May 2018
#
# File Name:   Install-SqlStigSolution.ps1
#
# Purpose:     PowerShell code to install/deploy STIG Data Warehouse project.
#
# History:
# Date         Name                     Comment
# -----------  -----------------------  -----------------------------------------------
# 05 May 2018  Brandon Adams (MSFT)     Created
# 08 May 2018  Adrian Rupp (MSFT)       Modified parameters and ConfigParameters logic / build 20180508.1700
# 14 May 2018  Adrian Rupp (MSFT)       Refactored to inculde more Config Parameters on Install
# 14 May 2018  Adrian Rupp (MSFT)       Repackage files for SourceControl
# 21 May 2018  Adrian Rupp (MSFT)       Removed Version# update to ConfigParam from PS1
# 02 Oct 2018  Adrian Rupp (MSFT)       Added License logic and STIGPAC logic
# 24 Oct 2018  Adrian Rupp (MSFT)       Added License new logic 
# 13 Feb 2019  Adrian Rupp (MSFT)       Added License new logic for STIGMonitor Version
# 30 May 2019  Adrian Rupp (MSFT)       Change installation message / new build for 5/30/2019 remove trigger
# -------------------------------------------------------------------------------------
#
<# For best results modify this script and run from the path of this file.
   For best results do not use spaces. If you need spaces use "double quote" to identify the text

.\Install-SqlStigSolution.ps1 `
-SourceFile: F:\Deploy\deploy\STIGMonitor.bacpac `
-InstallPath: F:\STIGMonitor `
-PolicyServer: SqlStigMonitor\STIG2014 `
-DataWarehouseName: StigMonitor `
-CMSGroup: MAG `
-IsLocal_1_or_0: 0 `
-CustomerName: "User Name For License" `
-CustomerEmail: user@mail.mil `
-NumberOfSQLInstances: 3

#>
# Copyright (C) 2018 Microsoft Corporation
#
# Disclaimer:
#   This is SAMPLE code that is NOT production ready. It is the sole intention of this code to provide a proof of concept as a
#   learning tool for Microsoft Customers. Microsoft does not provide warranty for or guarantee any portion of this code
#   and is NOT responsible for any affects it may have on any system it is executed on  or environment it resides within.
#   Please use this code at your own discretion!
# Additional legalese:
#   This Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.
#   THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
#   INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
#   We grant You a nonexclusive, royalty-free right to use and modify the Sample Code and to reproduce and distribute
#   the object code form of the Sample Code, provided that You agree:
#       (i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code is embedded;
#      (ii) to include a valid copyright notice on Your software product in which the Sample Code is embedded; and
#     (iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or lawsuits, including attorneys' fees,
#           that arise or result from the use or distribution of the Sample Code.
#

#Requires -RunAsAdministrator

<#
    .SYNOPSIS
    Installs the SQL STIG Compliance Datawarehouse Application

    .PARAMETER SourceFile
    BACPAC from which the database will be deployed

    .PARAMETER InstallPath
    The target directory for installed script files

    .PARAMETER PolicyServer
    The SQL Server instance hosting the STIG Compliance Datawarehouse

    .PARAMETER DataWarehouseName
    Name of the database to be used for deployment.
    (Default: StigDatawarehouse)

    .NOTES
    Disclaimer:
    This is SAMPLE code that is NOT production ready. It is the sole intention of this code to provide a proof of concept as a
    learning tool for Microsoft Customers. Microsoft does not provide warranty for or guarantee any portion of this code
    and is NOT responsible for any affects it may have on any system it is executed on  or environment it resides within.
    Please use this code at your own discretion!
    Additional legalese:
    This Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.
    THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
    INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
    We grant You a nonexclusive, royalty-free right to use and modify the Sample Code and to reproduce and distribute
    the object code form of the Sample Code, provided that You agree:
        (i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code is embedded;
        (ii) to include a valid copyright notice on Your software product in which the Sample Code is embedded; and
        (iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or lawsuits, including attorneys' fees,
            that arise or result from the use or distribution of the Sample Code.
#>
[CmdletBinding()]
param
(
    [Parameter(
        Mandatory = $true,
        ValueFromPipeline = $true
    )]
    [System.IO.FileInfo]
    $SourceFile,

    [Parameter(Mandatory = $true)]
    [System.IO.DirectoryInfo]
    $InstallPath,
    
    [Parameter(Mandatory = $true)]
    [System.String]
    $PolicyServer,

    [Parameter(Mandatory = $true)]
    [System.String]
    $DataWarehouseName,

    [Parameter(Mandatory = $true)]
    [System.String]
    $CMSGroup,

    [Parameter(Mandatory = $true)]
    [System.String]
    $IsLocal_1_or_0,

    [Parameter(Mandatory = $true)]
    [System.String]
    $CustomerName,

    [Parameter(Mandatory = $true)]
    [System.String]
    $CustomerEmail,

    [Parameter(Mandatory = $true)]
    [System.String]
    $NumberOfSQLInstances

)

# Used to mark that specific steps have completed.
$databaseDeployed = $false
$scriptsDeployed = $False

# Path in which SqlPackage is located
$searchPath = 'C:\Program Files (x86)\Microsoft SQL Server'

Write-Verbose -Message 'Searching for SqlPackage binary'

$sqlPackagePath = Get-ChildItem -Path $searchPath -Filter 'SqlPackage.exe' -Recurse -File |
    Sort-Object -Property FullName -Descending | 
    Select-Object -First 1 -ExpandProperty FullName

if ($sqlPackagePath)
{
    # Build an array of parameters for SqlPackage
    $deploymentParameters = @(
        '/Action:Import'
        '/Quiet:True'
        "/SourceFile:`"$($SourceFile.FullName)`""
        "/TargetServerName:$PolicyServer"
        "/TargetDatabaseName:$DataWarehouseName"
        "/TargetTimeout:120"
    )

    Write-Verbose 'Deploying the BACPAC'
    Write-Verbose "Parameters: $($deploymentParameters -join ' ')"

    $startProcessParameters = @{
        FilePath = $sqlPackagePath
        ArgumentList = $deploymentParameters
        Wait = $true
        PassThru = $true
    }

    $result = Start-Process -FilePath $sqlPackagePath -ArgumentList $deploymentParameters -NoNewWindow -Wait -PassThru

    if ($result.ExitCode -ne 0)
    {
        throw "Unable to deploy STIG Monitor. Ensure the SQL instance is online and accessible, that the database $DataWarehouseName does not exist."
    }

    $databaseDeployed = $true
}
else
{
    throw 'Unable to locate SqlPackage.exe. Ensure SQL Server Management Studio is installed! Download from https://aka.ms/ssms'
}

if ($databaseDeployed)
{
    Write-Output 'Begin script deployment...'
    Write-Verbose -Message 'Loading compression libraries.'

    # Import the .NET Compression classes
    Add-Type -AssemblyName 'System.IO.Compression, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089' -ErrorAction Stop -Verbose
    Add-Type -AssemblyName 'System.IO.Compression.FileSystem, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089' -ErrorAction Stop -Verbose

    # Create the root installation directory if it does not already exist
    if (-not (Test-Path -Path $InstallPath -PathType Container))
    {
        Write-Verbose -Message "Creating installation path: $InstallPath"
        New-Item -Path $InstallPath -ItemType Directory -Force -ErrorAction Stop > $null
    }

    Write-Verbose -Message 'Opening deployment package'
    # Open a stream to the BACPAC file
    $bacpacStream = New-Object System.IO.FileStream $SourceFile.FullName, 'Open'

    try
    {
        # ZipArchive to allow for reading the BACPAC contents
        $bacpacArchive = New-Object System.IO.Compression.ZipArchive $bacpacStream, 'Read'

        try 
        {
            # Manifest will be extracted to a temporary file for processing
            $manifestTempFile = [System.IO.Path]::GetTempFileName()
            $manifestEntry = $bacpacArchive.GetEntry('Manifest.xml')
            
            # Extract the Manifest to a temporary location
            [System.IO.Compression.ZipFileExtensions]::ExtractToFile($manifestEntry, $manifestTempFile, $true) > $null

            # Read the manifest into an object
            $manifest = Import-Clixml -Path $manifestTempFile -ErrorAction Stop

            # Delete the temporary Manifest file
            Remove-Item -Path $manifestTempFile -Force -ErrorAction SilentlyContinue > $null

            Write-Output 'Deploying files'

            # Extract files to disk
            foreach($file in $manifest.Files.GetEnumerator())
            {
                $targetFolder = $file.Target.Replace('{InstallPath}', $InstallPath)
                $targetFileName = [System.IO.Path]::GetFileName($file.EntryName)
                $targetFilePath = Join-Path -Path $targetFolder -ChildPath $targetFileName

                # Ensure the target folder exists
                if (-not (Test-Path -Path $targetFolder -PathType Container))
                {
                    Write-Verbose " > Creating directory '$targetFolder'"
                    New-Item -Path $targetFolder -ItemType Directory -Force -ErrorAction Stop > $null
                }

                # Extract the file
                Write-Verbose " >> Extracting '$targetFilePath'"

                try 
                {
                    $fileEntry = $bacpacArchive.GetEntry($file.EntryName)
                    [System.IO.Compression.ZipFileExtensions]::ExtractToFile($fileEntry, $targetFilePath, $true) > $null   
                }
                catch {
                    Write-Error $_.ToString()
                    throw   
                }

                # Get the hash for the extracted file
                $checksum = Get-FileHash -Path $targetFilePath -Algorithm SHA256

                # Determine whether the checksum is a match
                if ($checksum.Hash -ne $file.Checksum)
                {
                    Write-Warning -Message "Bad Checksum => $targetFilePath"
                    Remove-Item -Path $targetFilePath -Force -ErrorAction SilentlyContinue 
                }

                Write-Output " > $targetFilePath"
            }

            # Signal that the scripts have been successfully deployed
            $scriptsDeployed = $true

            Write-Output 'End Script Deployment'
        }
        finally
        {
            $bacpacArchive.Dispose()
        }
    }
    finally
    {
        $bacpacStream.Dispose()
    }
}

if ($databaseDeployed -and $scriptsDeployed)
{
    Write-Output 'Begin database configuration...'
    Write-Verbose -Message 'Loading SMO libraries'

    # Attempt to load assemblies by name starting with the latest version
    try 
    {
        # SMO v14 - SQL Server 2017 / SSMS 17.x
        Add-Type -AssemblyName 'Microsoft.SqlServer.Management.RegisteredServers, Version=14.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91' -ErrorAction Stop
        Add-Type -AssemblyName 'Microsoft.SqlServer.ConnectionInfo, Version=14.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91' -ErrorAction Stop
    }
    catch
    {
        try
        {
            # SMO v13 - SQL Server 2016
            Add-Type -AssemblyName 'Microsoft.SqlServer.Management.RegisteredServers, Version=13.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91' -ErrorAction Stop
            Add-Type -AssemblyName 'Microsoft.SqlServer.ConnectionInfo, Version=13.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91' -ErrorAction Stop
        }
        catch
        {
            try
            {
                # SMO v12 - SQL Server 2014
                Add-Type -AssemblyName 'Microsoft.SqlServer.Management.RegisteredServers, Version=12.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91' -ErrorAction Stop
                Add-Type -AssemblyName 'Microsoft.SqlServer.ConnectionInfo, Version=12.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91' -ErrorAction Stop
            }
            catch
            {
                try
                {
                    # SMO v11 - SQL Server 2012
                    Add-Type -AssemblyName 'Microsoft.SqlServer.Management.RegisteredServers, Version=11.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91' -ErrorAction Stop
                    Add-Type -AssemblyName 'Microsoft.SqlServer.ConnectionInfo, Version=11.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91' -ErrorAction Stop
                }
                catch
                {
                    Write-Warning 'SMO components not installed. Download from https://aka.ms/smo-latest'
                    break
                }
            }
        }
    }

    <#
        .SYNOPSIS
        Processes errors encoutered in PowerShell code.

        .DESCRIPTION
        The Get-SqlConnection function processes either PowerShell errors or application errors defined within your code.

        .INPUTS
        None

        .OUTPUTS
        None

        .EXAMPLE
        try { 1/0 } catch { Get-Error $Error }
        This passes the common error object (System.Management.Automation.ErrorRecord) for processing.

        .EXAMPLE
        try { 1/0 } catch { Get-Error "You attempted to divid by zero. Try again." }
        This passes a string that is output as an error message.

        .LINK
        Get-SqlConnection 
    #>
    function Get-Error
    {
        [CmdletBinding()]
        param
        (    
            [Parameter(Position = 0, ParameterSetName = 'PowerShellError', Mandatory = $true)] 
            [System.Management.Automation.ErrorRecord]
            $PSError,
            
            [Parameter(Position = 0, ParameterSetName = 'ApplicationError', Mandatory = $true)]
            [string]
            $AppError,
            
            [Parameter(Position = 1, Mandatory = $false)]
            [switch]
            $ContinueAfterError
        )
    
        if ($PSError)
        {
            #Process a PowerShell error
            Write-Host '******************************'
            Write-Host "Error Count: $($PSError.Count)"
            Write-Host '******************************'
    
            Write-Host "Line: $($PSError.InvocationInfo.ScriptLineNumber)"
            Write-Host "Code: $($PSError.InvocationInfo.Line.Trim())"
    
            #This will output the most recent $sqlQuery value which will help with troubleshooting
            if ($PSError.InvocationInfo.Line -like '*$sqlQuery*')
            {
                Write-Host "`$sqlQuery: $($sqlQuery)`n"
            }
    
            $err = $PSError.Exception
            Write-Host $err.Message -ForegroundColor Red
            $err = $err.InnerException

            while ($err.InnerException)
            {
                Write-Host $err.InnerException.Message -ForegroundColor Red
                $err = $err.InnerException
            }
            
            if ($ContinueAfterError) 
            { 
                Continue 
            }
            else 
            { 
                Throw 
            }
        }
        elseif ($AppError)
        {
            #Process an application error
            Write-Host '******************************'
            Write-Host 'Error Count: 1'
            Write-Host '******************************'
            Write-Host $AppError -ForegroundColor Red
            if ($ContinueAfterError) { Continue }
            else { Throw }
        }
    } #Get-Error
    
    <#
        .SYNOPSIS
        Gets a ServerConnection.

        .DESCRIPTION
        The Get-SqlConnection function  gets a ServerConnection to the specified SQL Server.

        .INPUTS
        None
        You cannot pipe objects to Get-SqlConnection 

        .OUTPUTS
        Microsoft.SqlServer.Management.Common.ServerConnection
        Get-SqlConnection returns a Microsoft.SqlServer.Management.Common.ServerConnection object.

        .EXAMPLE
        Get-SqlConnection "Z002\sql2K8"
        This command gets a ServerConnection to SQL Server Z002\SQL2K8.

        .EXAMPLE
        Get-SqlConnection "Z002\sql2K8" "sa" "Passw0rd"
        This command gets a ServerConnection to SQL Server Z002\SQL2K8 using SQL authentication.

        .LINK
        Get-SqlConnection 
    #>
    function Get-SqlConnection 
    {
        [CmdletBinding()]
        param
        (
            [Parameter(Mandatory = $true)] 
            [string]
            $sqlserver,

            [Parameter()]
            [string]
            $databaseName,
        
            [Parameter(Mandatory = $false)] 
            [string]
            $applicationName = 'STIG Compliance Installer'
        )
    
        Write-Verbose "Get-SqlConnection : $sqlserver`:$databaseName"
        
        if ($Username -and $Password)
        {
            try { $con = New-Object ('Microsoft.SqlServer.Management.Common.ServerConnection') $sqlserver, $username, $password }
            catch { Get-Error $_ }
        }
        else
        {
            try { $con = New-Object ('Microsoft.SqlServer.Management.Common.ServerConnection') $sqlserver }
            catch { Get-Error $_ }
        }
        
        $con.ApplicationName = $applicationName
        $con.DatabaseName = $databaseName
    
        try
        {
            $con.Connect()
        }
        catch
        {
            Get-Error $_ -ContinueAfterError
        }
    
        Write-Output $con
        
    } #Get-ServerConnection

    Write-Verbose -Message 'Connecting to PolicyServer...'
    $dwConn = Get-SqlConnection -sqlServer $PolicyServer -databaseName $DataWarehouseName

    # Configure the synonyms on this instance
    Write-Output ' > Creating synonyms'
    $dwConn.ExecuteNonQuery('EXEC STIG.usp_sysBuildSynonym') > $null

    Write-Output ' > Updating configuration parameters'
    $dwConn.ExecuteNonQuery('EXEC STIG.usp_sysSetConfigParameters') > $null

    Write-Output ' > Generate the CMS Function'
    $dwConn.ExecuteNonQuery('EXEC STIG.usp_sysCreateCMSFunction') > $null

    Write-Output '   + PowerShell Path'
    $dwConn.ExecuteNonQuery("UPDATE STIG.ConfigParameter SET ParameterValue = '$InstallPath'  WHERE ParameterName = 'PowerShellPath';") > $null
    
# Added for completeness of Config Parameters
    Write-Output '   + CMSGroup'
    $dwConn.ExecuteNonQuery("UPDATE STIG.ConfigParameter SET ParameterValue = '$CMSGroup'  WHERE ParameterName = 'CMSGroup';") > $null
    
    Write-Output '   + CMSServer'
    $dwConn.ExecuteNonQuery("UPDATE STIG.ConfigParameter SET ParameterValue = '$PolicyServer'  WHERE ParameterName = 'CMSServer';") > $null

    Write-Output '   + DWNames'
    $dwConn.ExecuteNonQuery("UPDATE STIG.ConfigParameter SET ParameterValue = '$DataWarehouseName'  WHERE ParameterName = 'DWNames';") > $null

    Write-Output '   + IsLocal'
    $dwConn.ExecuteNonQuery("UPDATE STIG.ConfigParameter SET ParameterValue =$IsLocal_1_or_0  WHERE ParameterName = 'IsLocal';") > $null

    Write-Output '   + LicenseUser'
    $dwConn.ExecuteNonQuery("UPDATE STIG.ConfigParameter SET ParameterValue = '$CustomerName' WHERE ParameterName = 'LicenseUser';") > $null
   
    Write-Output '   + CustomerEmail'
    $dwConn.ExecuteNonQuery("UPDATE STIG.ConfigParameter SET ParameterValue = ' $CustomerEmail' WHERE ParameterName = 'CustomerEmail';") > $null

    Write-Output '   + NumberOfSQLInstances'
    $dwConn.ExecuteNonQuery("UPDATE STIG.ConfigParameter SET ParameterValue = ' $NumberOfSQLInstances' WHERE ParameterName = 'NumberOfSQLInstances';") > $null

    # Create the SQL Agent Proxy account
    Write-Output ' > Creating Proxy'
    $dwConn.ExecuteNonQuery('EXEC STIG.usp_sysCreateProxy') > $null

    # Create the initial SQL Agent job for checking compliance
    Write-Output ' > Creating SQL Agent job'
    $dwConn.ExecuteNonQuery('EXEC STIG.usp_sysBuildSQLAgentJob') > $null

    # Create LicenseKey Challenge value
    Write-Output ' > Activate License'
    $dwConn.ExecuteNonQuery('EXEC STIG.ActivateLicense') > $null

    ############### Declarations ###############
    $ChallengeQuery = "SELECT [STIG].[fn_Object]()"
    $EncryptionQuery = "SELECT [STIG].[fn_Server]()"
    $VersionQuery = "SELECT  STIG.fn_Param('STIGDWVersion')"

    $challenge = (Invoke-Sqlcmd -ServerInstance $PolicyServer -Database $DataWarehouseName -Query $ChallengeQuery).Column1 ##The .Column1 is the name of the column returned, this strips that for a pure result without table format.
    $encryption = (Invoke-Sqlcmd -ServerInstance $PolicyServer -Database $DataWarehouseName -Query $EncryptionQuery).Column1 ##The .Column1 is the name of the column returned, this strips that for a pure result without table format.
    $version = (Invoke-Sqlcmd -ServerInstance $PolicyServer -Database $DataWarehouseName -Query $VersionQuery).Column1 ##The .Column1 is the name of the column returned, this strips that for a pure result without table format.
    
    Write-Host "Log into https://aka.ms/STIGMonitor to generate a License Key"  -ForegroundColor Yellow
    Write-Host "using the key information below."  -ForegroundColor Yellow
    Write-Host "Customer/Org Name      : $CustomerName <<<"  -ForegroundColor Green
    Write-Host "License Key Challenge  : $challenge ^^^"  -ForegroundColor Green
    Write-Host "Encryption Key Value   : $encryption >>>"  -ForegroundColor Green    
    Write-Host "Customer Email Address : $CustomerEmail"  -ForegroundColor Green
    Write-Host "Number of SQL Instances: $NumberOfSQLInstances"  -ForegroundColor Green
    Write-Host "STIGMonitor Version    : $version"  -ForegroundColor Green
    Write-Host "You will receive a FREE License Key and instructions for full functionality."  -ForegroundColor Yellow
    Write-Host "If you have any questions, please e-mail STIGMonitor@microsoft.com"  -ForegroundColor Yellow
    
    Write-Output ''
    Write-Output 'Database configuration complete.'
}

Write-Output ''
Write-Output '*** Installation Complete ***'

if (-not $psISE)
{
    Write-Output ''
    Write-Output 'Press any key to continue...'

    # Await a keypress
    $null = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}