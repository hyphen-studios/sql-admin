﻿# -------------------------------------------------------------------------------------------------------------------------------------------
# Author:      Daniel Mellor, Microsoft
#              Brandon Adams, Microsoft
#
# Date:        Apr 2019
#
# File Name:   Install-StigMonitorGUI.ps1
#
# Purpose:     PowerShell GUI to simplify installation of SQL STIG Monitor
#
# History:
# Date         Name                     Comment
# -----------  -----------------------  -----------------------------------------------------------------------------------------------------
# 15 APR 2019  Daniel Mellor    (MSFT)  Created
# 22 APR 2019  Brandon Adams    (MSFT)  LocalInstall to Checkbox, Removed Resizing, Custom Objects for Properties, Install Method
# 22 APR 2019  Daniel Mellor    (MSFT)  Removed Tip Text, Added Tooltips, Resized texboxes and window, Removed defaults; Added browse buttons
# 06 MAY 2019  Daniel Mellor    (MSFT)  Corrected SourceFolder, SourceFile, CMSGroup variables to capture and process installation
# 30 May 2019  Adrian Rupp      (MSFT)  Change installation message / new build for 5/30/2019 remove trigger
# -------------------------------------------------------------------------------------------------------------------------------------------
#
# Copyright (C) 2019 Microsoft Corporation
#
# Disclaimer:
#   This is SAMPLE code that is NOT production ready. It is the sole intention of this code to provide a proof of concept as a
#   learning tool for Microsoft Customers. Microsoft does not provide warranty for or guarantee any portion of this code
#   and is NOT responsible for any affects it may have on any system it is executed on  or environment it resides within.
#   Please use this code at your own discretion!
# Additional legalese:
#   This Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.
#   THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
#   INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
#   We grant You a nonexclusive, royalty-free right to use and modify the Sample Code and to reproduce and distribute
#   the object code form of the Sample Code, provided that You agree:
#       (i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code is embedded;
#      (ii) to include a valid copyright notice on Your software product in which the Sample Code is embedded; and
#     (iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or lawsuits, including attorneys' fees,
#           that arise or result from the use or distribution of the Sample Code.
#
# -------------------------------------------------------------------------------------------------------------------------------------------

#Requires -RunAsAdministrator
<#
  ##Tests if not running as admin, then launches powershell as admin if it can elevate
param([switch]$Elevated)

Function Test-Admin 
{
  $currentUser = New-Object Security.Principal.WindowsPrincipal $([Security.Principal.WindowsIdentity]::GetCurrent())
  $currentUser.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
}

IF ((Test-Admin) -eq $false)
{
    IF ($Elevated) 
    {
        Write-Host "Could not automatically elevate. Rerun script as Admin."
    } 
    ELSE
    {
        Start-Process Powershell.exe -Verb RunAs -ArgumentList ('-noprofile -noexit -file "{0}" -elevated' -f ($myinvocation.MyCommand.Definition))
    }
exit
}
'Running as Admin'
#>

Add-Type –AssemblyName PresentationFramework

[xml]$xaml = @'
<Window 
        xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        xmlns:d="http://schemas.microsoft.com/expression/blend/2008"
        xmlns:local="clr-namespace:SqlStigInstaller"
        Title="SQL STIG Monitor Installer" Height="325" Width="600" ResizeMode="NoResize">
    <Grid>
        <Button x:Name="bInstall" Content="INSTALL" HorizontalAlignment="Center" Height="40" Margin="0,0,0,10" VerticalAlignment="Bottom" Width="100"/>
        <TextBlock HorizontalAlignment="Left" Height="14" Margin="10,60,0,0" TextWrapping="Wrap" Text="Source File: " VerticalAlignment="Top" Width="140" FontWeight="Bold"/>
        <TextBlock HorizontalAlignment="Left" Height="14" Margin="10,80,0,0" TextWrapping="Wrap" Text="Install Path:" VerticalAlignment="Top" Width="140" FontWeight="Bold"/>
        <TextBlock HorizontalAlignment="Left" Height="14" Margin="10,100,0,0" TextWrapping="Wrap" Text="Policy Server:" VerticalAlignment="Top" Width="140" FontWeight="Bold"/>
        <TextBlock HorizontalAlignment="Left" Height="14" Margin="10,120,0,0" TextWrapping="Wrap" Text="Data Warehouse Name:" VerticalAlignment="Top" Width="140" FontWeight="Bold"/>
        <TextBlock HorizontalAlignment="Left" Height="14" Margin="10,140,0,0" TextWrapping="Wrap" Text="CMS Group:" VerticalAlignment="Top" Width="140" FontWeight="Bold"/>
        <TextBlock HorizontalAlignment="Left" Height="14" Margin="10,160,0,0" TextWrapping="Wrap" Text="Local Install:" VerticalAlignment="Top" Width="140" FontWeight="Bold"/>
        <TextBlock HorizontalAlignment="Left" Height="14" Margin="10,180,0,0" TextWrapping="Wrap" Text="Customer Name:" VerticalAlignment="Top" Width="140" FontWeight="Bold"/>
        <TextBlock HorizontalAlignment="Left" Height="14" Margin="10,200,0,0" TextWrapping="Wrap" Text="Customer Email:" VerticalAlignment="Top" Width="140" FontWeight="Bold"/>
        <TextBlock HorizontalAlignment="Left" Height="14" Margin="10,220,0,0" TextWrapping="Wrap" Text="SQL Instances:" VerticalAlignment="Top" Width="140" FontWeight="Bold"/>

        <TextBox x:Name="SourceFile" HorizontalAlignment="Left" Height="16" Margin="155,60,0,0" Text="{Binding SourceFile}" VerticalAlignment="Top" Width="350" FontSize="10" ToolTipService.ToolTip="Path to the bacpac file"/>
        <TextBox x:Name="InstallPath"  HorizontalAlignment="Left" Height="16" Margin="155,80,0,0" Text="{Binding InstallPath}" VerticalAlignment="Top" Width="350" FontSize="10" ToolTipService.ToolTip="Path where the files will be copied"/>
        <TextBox x:Name="PolicyServer" HorizontalAlignment="Left" Height="16" Margin="155,100,0,0" Text="{Binding PolicyServer}" VerticalAlignment="Top" Width="350" FontSize="10" ToolTipService.ToolTip="Server\Instance to install; just use Server for default instances"/>
        <TextBox x:Name="DatabaseName" HorizontalAlignment="Left" Height="16" Margin="155,120,0,0" Text="{Binding DatabaseName}" VerticalAlignment="Top" Width="350" FontSize="10" ToolTipService.ToolTip="Database name to be created"/>
        <TextBox x:Name="CMSGroupName" HorizontalAlignment="Left" Height="16" Margin="155,140,0,0" Text="{Binding CMSGroupName}" VerticalAlignment="Top" Width="350" FontSize="10" ToolTipService.ToolTip="Name of CMS registered group"/>
        <CheckBox x:Name="IsLocalInstall" HorizontalAlignment="Left" Margin="155,160,0,0" VerticalAlignment="Top" IsChecked="{Binding IsLocalInstall}" ToolTipService.ToolTip="Uncheck if using a CMS"/>
        <TextBox x:Name="CustomerName" HorizontalAlignment="Left" Height="16" Margin="155,180,0,0" Text="{Binding CustomerName}" VerticalAlignment="Top" Width="350" FontSize="10" ToolTipService.ToolTip="Civilian contact name for updates"/>
        <TextBox x:Name="CustomerEmail" HorizontalAlignment="Left" Height="16" Margin="155,200,0,0" Text="{Binding CustomerEmail}" VerticalAlignment="Top" Width="350" FontSize="10" ToolTipService.ToolTip="Email address of contact"/>
        <TextBox x:Name="InstanceCount" HorizontalAlignment="Left" Height="16" Margin="155,220,0,0" Text="{Binding InstanceCount}" VerticalAlignment="Top" Width="30" FontSize="10" ToolTipService.ToolTip="Estimated # of instances supported"/>

        <TextBlock HorizontalAlignment="Left" Height="45" Margin="10,10,0,0" TextWrapping="Wrap" VerticalAlignment="Top" Width="500" FontSize="10"><Run FontWeight="Bold" Text="To run the installation of the bacpac and copy files, complete the fields below and select INSTALL."/><LineBreak/><Run Text="This only needs to be performed on one server if using a Central Management Server (CMS)."/></TextBlock>

        <Button x:Name="bBrowseSource"  FontSize="10" Content="Browse" HorizontalAlignment="Center" Height="16" Margin="490,59,0,0" VerticalAlignment="Top" Width="60"/>
        <Button x:Name="bBrowseInstall" FontSize="10" Content="Browse" HorizontalAlignment="Center" Height="16" Margin="490,79,0,0" VerticalAlignment="Top" Width="60"/>

    <!-- 
        <TextBlock HorizontalAlignment="Left" Height="14" Margin="370,60,0,0" TextWrapping="Wrap" VerticalAlignment="Top" Width="140" FontStyle="Italic" FontSize="8"><Text="Path to the bacpac file"/>
        <TextBlock HorizontalAlignment="Left" Height="14" Margin="370,80,0,0" TextWrapping="Wrap" VerticalAlignment="Top" Width="140" FontStyle="Italic" FontSize="8" Text="Path where files will be copied"/>
        <TextBlock HorizontalAlignment="Left" Height="14" Margin="370,100,0,0" TextWrapping="Wrap" VerticalAlignment="Top" Width="140" FontStyle="Italic" FontSize="8" Text="Server\Instance to install"/>
        <TextBlock HorizontalAlignment="Left" Height="14" Margin="370,120,0,0" TextWrapping="Wrap" VerticalAlignment="Top" Width="140" FontStyle="Italic" FontSize="8" Text="Database name to be created"/>
        <TextBlock HorizontalAlignment="Left" Height="14" Margin="370,140,0,0" TextWrapping="Wrap" VerticalAlignment="Top" Width="140" FontStyle="Italic" FontSize="8" Text="Name of CMS registered group"/>
        <TextBlock HorizontalAlignment="Left" Height="14" Margin="370,160,0,0" TextWrapping="Wrap" VerticalAlignment="Top" Width="140" FontStyle="Italic" FontSize="8" Text="Uncheck if using a CMS"/>
        <TextBlock HorizontalAlignment="Left" Height="14" Margin="370,180,0,0" TextWrapping="Wrap" VerticalAlignment="Top" Width="140" FontStyle="Italic" FontSize="8" Text="Civilian contact name for updates"/>
        <TextBlock HorizontalAlignment="Left" Height="14" Margin="370,200,0,0" TextWrapping="Wrap" VerticalAlignment="Top" Width="140" FontStyle="Italic" FontSize="8" Text="Email address of contact"/>
        <TextBlock HorizontalAlignment="Left" Height="14" Margin="370,220,0,0" TextWrapping="Wrap" VerticalAlignment="Top" Width="140" FontStyle="Italic" FontSize="8" Text="Estimated # of instances supported"/>
    -->

    </Grid>
</Window>
'@

# XmlNodeReader to parse the XAML defined above
$reader = New-Object -TypeName System.Xml.XmlNodeReader -ArgumentList $xaml

# Instantiate a window from the XAML
$window = [System.Windows.Markup.XamlReader]::Load($reader)

# Define a custom object for data binding into the form
$userInstallation = New-Object psobject -Property @{
    SourceFile = "$PSScriptRoot\StigMonitor.bacpac"
    InstallPath = 'C:\MSSQL\StigMonitor'
    DatabaseName = 'StigMonitor'
    IsLocalInstall = $true
    PolicyServer = "$Env:ComputerName"
    CMSGroupName = 'None'
    CustomerName = ''
    CustomerEmail = ''
    InstanceCount = 1
}

# Attach a click handler for the Browse Source File Button
$window.FindName('bBrowseSource').Add_click({
    $FileBrowser = New-Object System.Windows.Forms.OpenFileDialog #-Property @{
    $FileBrowser.Multiselect = $False
    $FileBrowser.FileName = $PSScriptRoot
    $FileBrowser.Filter = 'Bacpac (*.bacpac)|*.bacpac|PowerShell (*.ps1)|*.ps1|All Files (*.*)|*.*'
   
    IF($FileBrowser.ShowDialog() -eq "OK")
    {
        $window.FindName('SourceFile').Text = $FileBrowser.FileName
    }
})

# Attach a click handler for the Browse Install Folder Button
$window.FindName('bBrowseInstall').Add_click({
    $FolderBrowser = New-Object System.Windows.Forms.FolderBrowserDialog
	$FolderBrowser.SelectedPath = "C:\"
    $FolderBrowser.Description = "Select a Directory"
 
    IF($FolderBrowser.ShowDialog() -eq "OK")
    {
        $window.FindName('InstallPath').Text = $FolderBrowser.SelectedPath
    }
})

# Create a function to execute the installation process
$userInstallation | Add-Member -MemberType ScriptMethod -Name Install -Value {
$SourceFolder = split-path $($this.SourceFile)
    $processParameters = @{
        Verbose = $true
        Verb = 'RunAs'
        PassThru = $true
        FilePath = (Get-Command -Name powershell.exe).Path
        ArgumentList = @(
            "-File `"$($SourceFolder)\Install-SqlStigSolution.ps1 `""##`"$(Join-Path -Path $SourceFolder -ChildPath 'Install-SqlStigSolution.ps1')`"" #Join path wasn't working for me
            "-SourceFile `"$($this.SourceFile)`"" #`"$(Join-Path $this.SourceFolder -ChildPath 'StigMonitor.bacpac')`"" #no need to join with the file selection now
            "-InstallPath `"$($this.InstallPath)`""
            "-PolicyServer `"$($this.PolicyServer)`""
            "-DatawarehouseName `"$($this.DatabaseName)`""
            "-CMSGroup `"$($this.CMSGroupName)`""
            "-IsLocal `"$($this.IsLocalInstall -as [int])`""
            "-CustomerName `"$($this.CustomerName)`""
            "-CustomerEmail `"$($this.CustomerEmail)`""
            "-NumberOfSQLInstances `"$($this.InstanceCount -as [int])"
        )
    }

    # Launch the installation script
    Start-Process @processParameters #-Verbose 
    ## Needs some error handling, if any error occurs, window immediately closes, cannot read the red text before the window closes
    ## ideally embed script within here so no second window is opened
}

# Bind our custom object to the window
$window.DataContext = $userInstallation

# Attach a click handler to the button
$window.FindName('bInstall').Add_Click({
    Write-Host 'Beginning installation process.'
    # Call the Install() method on our data-bound object
    $userInstallation.Install()
})

# Display the window
$window.ShowDialog()